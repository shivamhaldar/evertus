A Logistics Admin Dashboard that monitors several warehouses that are handling imports and exports (international / local). 

Taking a scenario of containers where the imports/exports cargo comes via ship preferably as an example.

Only outlining mockup, no extra details added.

Access Demo : <a href="http://windowsgeekpro.in/modular_system/logisticsadmin/">Click here!</a>

For Donation : <br>
[![ko-fi](https://www.ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/ashumeow)



<a href="https://github.com/ashumeow/LogisticsAdmin/blob/master/LICENSE">License</a> And <a href="https://github.com/DashboardPack">Credits</a>
